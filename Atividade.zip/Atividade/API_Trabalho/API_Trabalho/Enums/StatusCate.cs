﻿using System.ComponentModel;

namespace API_Trabalho.Enums
{
        public enum StatusCate
        {
            [Description("Ativo")]
            Ativo = 1,
            [Description("Inativo")]
            Inativo = 2
        }
  
}
