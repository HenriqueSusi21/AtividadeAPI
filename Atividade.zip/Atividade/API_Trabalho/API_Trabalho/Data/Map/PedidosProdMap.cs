﻿using API_Trabalho.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace API_Trabalho.Data.Map
{
    public class PedidosProdMap : IEntityTypeConfiguration<PedidosProdModel>
    {
        public void Configure(EntityTypeBuilder<PedidosProdModel> builder)
        {
            builder.HasKey(x => x.ProdutoId);
            builder.Property(x => x.CategoriaId);
            builder.Property(x => x.Quantidade);

        }
    }
}
