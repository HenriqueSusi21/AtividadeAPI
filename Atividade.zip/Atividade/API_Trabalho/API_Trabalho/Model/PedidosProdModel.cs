﻿using API_Trabalho.Enums;

namespace API_Trabalho.Model
{
    public class PedidosProdModel
    {
        public int? ProdutoId { get; set; }
        public ProdutoModel? Produto { get; set; }
        public int? CategoriaId { get; set; }
        public CategoriaModel? Categoria { get; set; }
        public int Quantidade { get; set; }
    }
}
