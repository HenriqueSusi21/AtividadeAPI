﻿namespace API_Trabalho.Model
{
    public class PedidoModel
    {
        public int Id { get; set; }
        public int? UsuarioId { get; set; }
        public virtual UsuarioModel Usuario { get; set; }
        public string EnderecoEnt { get; set;}
    }
}
