﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API_Trabalho.Migrations
{
    /// <inheritdoc />
    public partial class PedidosProd2IntialDb : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
