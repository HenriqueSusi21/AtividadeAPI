﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace API_Trabalho.Migrations
{
    /// <inheritdoc />
    public partial class PedidosProdIntialDb : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PedidosProd",
                columns: table => new
                {
                    ProdutoId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProdutoId1 = table.Column<int>(type: "int", nullable: false),
                    CategoriaId = table.Column<int>(type: "int", nullable: true),
                    Quantidade = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PedidosProd", x => x.ProdutoId);
                    table.ForeignKey(
                        name: "FK_PedidosProd_Categoria_CategoriaId",
                        column: x => x.CategoriaId,
                        principalTable: "Categoria",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_PedidosProd_Produto_ProdutoId1",
                        column: x => x.ProdutoId1,
                        principalTable: "Produto",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PedidosProd_CategoriaId",
                table: "PedidosProd",
                column: "CategoriaId");

            migrationBuilder.CreateIndex(
                name: "IX_PedidosProd_ProdutoId1",
                table: "PedidosProd",
                column: "ProdutoId1");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PedidosProd");
        }
    }
}
