﻿using API_Trabalho.Model;
using Microsoft.AspNetCore.Mvc;
using API_Trabalho.Repositorio.Interface;

namespace API_Trabalho.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidosProdController : ControllerBase
    {
        private readonly IPedidosProdRepositorio _PedidosProdRepositorio;
        public PedidosProdController(IPedidosProdRepositorio pedidosProdRepositorio)
        {
            _PedidosProdRepositorio = pedidosProdRepositorio;
        }

        [HttpGet]
        public async Task<ActionResult<List<PedidosProdModel>>> BuscarTodasPedidosProds()
        {
            List<PedidosProdModel> PedidosProd = await _PedidosProdRepositorio.BuscarTodosPedidosProds();
            return Ok();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<PedidosProdModel>> BuscarPorId(int Id)
        {
            PedidosProdModel PedidosProd = await _PedidosProdRepositorio.BuscarPorId(Id);
            return Ok();
        }

        [HttpPost]

        public async Task<ActionResult<PedidosProdModel>> Adicionar([FromBody] PedidosProdModel pedidosProdModel)
        {
            PedidosProdModel PedidosProd = await _PedidosProdRepositorio.Adicionar(pedidosProdModel);
            return Ok();
        }

        [HttpPut("{id}")]

        public async Task<ActionResult<PedidosProdModel>> Atualizar(int id, [FromBody] PedidosProdModel pedidosProdModel)
        {
            pedidosProdModel.ProdutoId = id;
            PedidosProdModel PedidosProd = await _PedidosProdRepositorio.Atualizar(pedidosProdModel, id);
            return Ok();
        }

        [HttpDelete("{id}")]

        public async Task<ActionResult<PedidosProdModel>> Apagar(int id)
        {
            bool apagado = await _PedidosProdRepositorio.Apagar(id);
            return Ok(apagado);
        }
    }
}
