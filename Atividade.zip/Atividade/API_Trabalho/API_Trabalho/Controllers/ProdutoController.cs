﻿using API_Trabalho.Model;
using Microsoft.AspNetCore.Mvc;
using API_Trabalho.Repositorio.Interface;

namespace API_Trabalho.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProdutoController : ControllerBase
    {
        private readonly IProdutoRepositorio _ProdutoRepositorio;
        public ProdutoController(IProdutoRepositorio ProdutoRepositorio)
        {
            _ProdutoRepositorio = ProdutoRepositorio;
        }

        [HttpGet]
        public async Task<ActionResult<List<ProdutoModel>>> BuscarTodasProdutos()
        {
            List<ProdutoModel> Produto = await _ProdutoRepositorio.BuscarTodosProdutos();
            return Ok();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ProdutoModel>> BuscarPorId(int Id)
        {
            ProdutoModel Produto = await _ProdutoRepositorio.BuscarPorId(Id);
            return Ok();
        }

        [HttpPost]

        public async Task<ActionResult<ProdutoModel>> Adicionar([FromBody] ProdutoModel ProdutoModel)
        {
            ProdutoModel Produto = await _ProdutoRepositorio.Adicionar(ProdutoModel);
            return Ok();
        }

        [HttpPut("{id}")]

        public async Task<ActionResult<ProdutoModel>> Atualizar(int id, [FromBody] ProdutoModel ProdutoModel)
        {
            ProdutoModel.Id = id;
            ProdutoModel Produto = await _ProdutoRepositorio.Atualizar(ProdutoModel, id);
            return Ok();
        }

        [HttpDelete("{id}")]

        public async Task<ActionResult<ProdutoModel>> Apagar(int id)
        {
            bool apagado = await _ProdutoRepositorio.Apagar(id);
            return Ok(apagado);
        }
    }
}
