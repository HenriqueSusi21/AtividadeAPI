﻿using API_Trabalho.Model;
using Microsoft.AspNetCore.Mvc;
using API_Trabalho.Repositorio.Interface;

namespace API_Trabalho.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidoController : ControllerBase
    {
        private readonly IPedidoRepositorio _pedidoRepositorio;
        public PedidoController(IPedidoRepositorio pedidoRepositorio)
        {
            _pedidoRepositorio = pedidoRepositorio;
        }

        [HttpGet]
        public async Task<ActionResult<List<PedidoModel>>> BuscarTodosPedidos()
        {
            List<PedidoModel> pedido = await _pedidoRepositorio.BuscarTodosPedidos();
            return Ok();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<PedidoModel>> BuscarPorId(int Id)
        {
            PedidoModel tarefa = await _pedidoRepositorio.BuscarPorId(Id);
            return Ok(tarefa);
        }

        [HttpPost]

        public async Task<ActionResult<UsuarioModel>> Adicionar([FromBody] PedidoModel tarefaModel)
        {
            PedidoModel tarefa = await _pedidoRepositorio.Adicionar(tarefaModel);
            return Ok(tarefa);
        }

        [HttpPut("{id}")]

        public async Task<ActionResult<PedidoModel>> Atualizar(int id, [FromBody] PedidoModel pedidoModel)
        {
            pedidoModel.Id = id;
            PedidoModel usuario = await _pedidoRepositorio.Atualizar(pedidoModel, id);
            return Ok(usuario);
        }

        [HttpDelete("{id}")]

        public async Task<ActionResult<PedidoModel>> Apagar(int id)
        {
            bool apagado = await _pedidoRepositorio.Apagar(id);
            return Ok(apagado);
        }
    }
}
