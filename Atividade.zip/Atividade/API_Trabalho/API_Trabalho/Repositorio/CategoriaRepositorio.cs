﻿using Microsoft.EntityFrameworkCore;
using API_Trabalho.Data;
using API_Trabalho.Model;
using API_Trabalho.Repositorio.Interface;

namespace API.Trabalho.Repositorio
{
    public class CategoriaRepositorio : ICategoriaRepositorio
    {
        private readonly SistemasUsuarioDbContext DbContext;

        public CategoriaRepositorio(SistemasUsuarioDbContext sistemasUsuarioDbContext)
        {
            DbContext = sistemasUsuarioDbContext;
        }

        public async Task<CategoriaModel> BuscarPorId(int id)
        {
            return await DbContext.Categoria.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<CategoriaModel>> BuscarTodasCategorias()
        {
            return await DbContext.Categoria.ToListAsync();
        }
        public async Task<CategoriaModel> Adicionar(CategoriaModel categoria)
        {
            await DbContext.Categoria.AddAsync(categoria);
            await DbContext.SaveChangesAsync();

            return categoria;
        }
        public async Task<CategoriaModel> Atualizar(CategoriaModel categoria, int id)
        {
            CategoriaModel categoriaPorId = await BuscarPorId(id);
            if (categoriaPorId == null)
            {
                throw new Exception($"Categoria do ID: {id} nao foi encontrado");
            }
            categoriaPorId.Nome = categoria.Nome;
            categoriaPorId.Status = categoria.Status;

            DbContext.Categoria.Update(categoriaPorId);
            await DbContext.SaveChangesAsync();
            return categoriaPorId;
        }

        public async Task<bool> Apagar(int id)
        {
            CategoriaModel categoriaPorId = await BuscarPorId(id);
            if (categoriaPorId == null)
            {
                throw new Exception("Categoria nao encontrada");
            }
            DbContext.Categoria.Remove(categoriaPorId);
            await DbContext.SaveChangesAsync();

            return true;
        }
    }
}