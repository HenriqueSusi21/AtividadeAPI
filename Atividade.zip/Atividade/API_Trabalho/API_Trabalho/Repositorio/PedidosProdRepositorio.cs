﻿using Microsoft.EntityFrameworkCore;
using API_Trabalho.Data;
using API_Trabalho.Model;
using API_Trabalho.Repositorio.Interface;

namespace API.Trabalho.Repositorio
{
    public class PedidosProdRepositorio : IPedidosProdRepositorio
    {
        private readonly SistemasUsuarioDbContext DbContext;

        public PedidosProdRepositorio(SistemasUsuarioDbContext sistemasUsuarioDbContext)
        {
            DbContext = sistemasUsuarioDbContext;
        }

        public async Task<PedidosProdModel> BuscarPorId(int id)
        {
            return await DbContext.PedidosProd.FirstOrDefaultAsync(x => x.ProdutoId == id);
        }

        public async Task<List<PedidosProdModel>> BuscarTodosPedidosProds()
        {
            return await DbContext.PedidosProd.ToListAsync();
        }
        public async Task<PedidosProdModel> Adicionar(PedidosProdModel PedidosProd)
        {
            await DbContext.PedidosProd.AddAsync(PedidosProd);
            await DbContext.SaveChangesAsync();

            return PedidosProd;
        }
        public async Task<PedidosProdModel> Atualizar(PedidosProdModel PedidosProd, int id)
        {
            PedidosProdModel PedidosProdPorId = await BuscarPorId(id);
            if (PedidosProdPorId == null)
            {
                throw new Exception($"PedidosProd do ID: {id} nao foi encontrado");
            }
            PedidosProdPorId.ProdutoId = PedidosProd.ProdutoId;
            PedidosProdPorId.CategoriaId = PedidosProd.CategoriaId;
            PedidosProdPorId.Quantidade = PedidosProd.Quantidade;

            DbContext.PedidosProd.Update(PedidosProdPorId);
            await DbContext.SaveChangesAsync();
            return PedidosProdPorId;
        }

        public async Task<bool> Apagar(int id)
        {
            PedidosProdModel PedidosProdPorId = await BuscarPorId(id);
            if (PedidosProdPorId == null)
            {
                throw new Exception("PedidosProd nao encontrada");
            }
            DbContext.PedidosProd.Remove(PedidosProdPorId);
            await DbContext.SaveChangesAsync();

            return true;
        }
    }
}