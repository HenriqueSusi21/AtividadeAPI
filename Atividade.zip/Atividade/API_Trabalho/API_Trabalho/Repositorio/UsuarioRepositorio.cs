﻿using API_Trabalho.Model;
using API_Trabalho.Data;
using API_Trabalho.Repositorio.Interface;
using Microsoft.EntityFrameworkCore;

namespace API_Trabalho.Repositorio
{
    public class UsuarioRepositorio : IUsuarioRepositorio
    {
        private readonly SistemasUsuarioDbContext DbContext;

        public UsuarioRepositorio(SistemasUsuarioDbContext sistemaUsuariodbContext)
        {
            DbContext = sistemaUsuariodbContext;
        }
        public async Task<UsuarioModel> BuscarPorId(int id)
        {
            return await DbContext.Usuarios.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<UsuarioModel>> BuscarTodosUsuarios()
        {
            return await DbContext.Usuarios.ToListAsync();
        }
        public async Task<UsuarioModel> Adicionar(UsuarioModel usuario)
        {
            await DbContext.Usuarios.AddAsync(usuario);
            await DbContext.SaveChangesAsync();

            return usuario;
        }

        public async Task<bool> Apagar(int id)
        {
            UsuarioModel usuarioPorId = await BuscarPorId(id);

            if (usuarioPorId == null)
            {
                throw new Exception($"Usuario do Id:{id} não foi encontrado");
            }
            DbContext.Usuarios.Remove(usuarioPorId);
            await DbContext.SaveChangesAsync();

            return true;

        }

        public async Task<UsuarioModel> Atualizar(UsuarioModel usuario, int id)
        {
            UsuarioModel usuarioPorId = await BuscarPorId(id);

            if (usuarioPorId == null)
            {
                throw new Exception($"Usuário do Id: {id} não encontrado");
            }

            usuarioPorId.Nome = usuario.Nome;
            usuarioPorId.Email = usuario.Email;

            DbContext.Usuarios.Update(usuarioPorId);
            await DbContext.SaveChangesAsync();

            return usuario;
        }

    }
}
