﻿using API_Trabalho.Model;

namespace API_Trabalho.Repositorio.Interface
{
    public interface IPedidosProdRepositorio
    {
        Task<List<PedidosProdModel>> BuscarTodosPedidosProds();

        Task<PedidosProdModel> BuscarPorId(int id);

        Task<PedidosProdModel> Adicionar(PedidosProdModel PedidosProd);

        Task<PedidosProdModel> Atualizar(PedidosProdModel PedidosProd, int id);

        Task<bool> Apagar(int id);
    }
}
